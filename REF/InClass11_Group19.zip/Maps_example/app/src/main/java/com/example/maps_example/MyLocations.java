package com.example.maps_example;

import com.google.android.gms.maps.model.LatLng;

public class MyLocations {
    Double latitude,longitude;

}
