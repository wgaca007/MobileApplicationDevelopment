package com.example.maps_example;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.graphics.Camera;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    LatLng start;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    ArrayList<MyLocations> myLocations=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            setTitle("Paths Activity");

                SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                        .findFragmentById(R.id.map);
                mapFragment.getMapAsync(this);
            }
    public String loadJSONFromAsset(){
        String json = null;
        Context context = this;
        try {
            InputStream is = context.getAssets().open("trip.json");
            Log.d("demo1", is.toString());
            int size = is.available();
            byte[] buffer = new byte[10000];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");

            Log.d("demo", json.toString());
        } catch (IOException ex) {
            Log.d("demo1", "input mein problem");
            ex.printStackTrace();
        }
        return json;
    }
            @SuppressLint("MissingPermission")
            @Override
            public void onMapReady(GoogleMap googleMap) {
                mMap = googleMap;

                    myLocations=new ArrayList<>();

                String json=loadJSONFromAsset();

                    try {
                        JSONObject obj = new JSONObject(json);
                        JSONArray m_jArry = obj.getJSONArray("points");

                        for (int i = 0; i < m_jArry.length(); i++) {
                            JSONObject jo_inside = m_jArry.getJSONObject(i);
                            MyLocations location = new MyLocations();
                            location.latitude=jo_inside.getDouble("latitude");
                            location.longitude=jo_inside.getDouble("longitude");
                            myLocations.add(location);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                PolylineOptions polylineOptions = new PolylineOptions();
                polylineOptions
                        .width(10)
                        .color(Color.BLUE);

                    for(int i=0;i<myLocations.size();i++) {

                        LatLng loc = new LatLng(myLocations.get(i).latitude, myLocations.get(i).longitude);
                        builder.include(loc);
                        polylineOptions.add(loc);
                    }
                   int last=myLocations.size();
                     start=new LatLng(myLocations.get(0).latitude,myLocations.get(0).longitude);
                    LatLng end=new LatLng(myLocations.get(last-1).latitude,myLocations.get(last-1).longitude);
                mMap.addMarker(new MarkerOptions().position(start)).setTitle("Start Location");
                mMap.addMarker(new MarkerOptions().position(end)).setTitle("End Location");
                    mMap.addPolyline(polylineOptions);
                LatLngBounds bounds = builder.build();
                 int width = getResources().getDisplayMetrics().widthPixels;
                int height = getResources().getDisplayMetrics().heightPixels;
                int padding = (int) (width * 0.20);
            mMap.setLatLngBoundsForCameraTarget(bounds);
                mMap.getUiSettings().setZoomControlsEnabled(true);
               mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding));

            }
    }

