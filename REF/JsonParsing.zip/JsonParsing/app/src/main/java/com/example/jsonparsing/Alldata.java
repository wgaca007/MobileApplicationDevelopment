package com.example.jsonparsing;

import java.util.ArrayList;

public class Alldata {

    String status;
    String totalResults;
    ArrayList<Articles> articles=new ArrayList<>();
}
