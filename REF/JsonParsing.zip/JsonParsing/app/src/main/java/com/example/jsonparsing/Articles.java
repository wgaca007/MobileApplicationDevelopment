package com.example.jsonparsing;

public class Articles {

    String author,title,description,url,urltoimage,publishedat;
    Source src;

    @Override
    public String toString() {
        return "Articles{" +
                "author='" + author + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", url='" + url + '\'' +
                ", urltoimage='" + urltoimage + '\'' +
                ", publishedat='" + publishedat + '\'' +
                ", src=" + src +
                '}';
    }




    public Articles() {
    }
}
