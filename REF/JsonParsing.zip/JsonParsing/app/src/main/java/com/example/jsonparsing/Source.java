package com.example.jsonparsing;

public class Source {
    String id,name;

    @Override
    public String toString() {
        return "Source{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                '}';
    }

    public Source() {
    }
}
