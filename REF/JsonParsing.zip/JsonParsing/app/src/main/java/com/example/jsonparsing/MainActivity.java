package com.example.jsonparsing;

import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    final String[] category = {"business", "entertainment", "general", "health", "science"};
    int c=0;
    int pc=1;
    ArrayList <Articles> arrlist= new ArrayList<> ();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.Go_Button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Choose Category")
                        .setCancelable(false)
                        .setItems(category, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String checked = category[which];
                                new JSONParse().execute("https://newsapi.org/v2/top-headlines?country=us&category="+checked+"&apiKey=cba9fb842b384b7bb78e7b16f54a5000");
                                TextView tv1=(TextView) findViewById(R.id.ShowCategory);
                                tv1.setText(checked);
                            }
                        });
                builder.create().show();
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    public class JSONParse extends AsyncTask<String, Void, Alldata> {
        @Override
        protected Alldata doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader;
            ArrayList<String> arr = null;
            Alldata ald = new Alldata();
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String Json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    JSONObject root = new JSONObject(Json);
                    ald.totalResults = root.getString("totalResults");
                    JSONArray jArray = root.getJSONArray("articles");
                    for (int k = 0; k <= jArray.length(); k++) {
                        JSONObject jsobj1 = jArray.getJSONObject(k);
                        Articles art = new Articles();
                        art.title = jsobj1.getString("title");
                        art.urltoimage = jsobj1.getString("urlToImage");
                        art.publishedat = jsobj1.getString("publishedAt");
                        art.description=jsobj1.getString("description");
                        ald.articles.add(art);
                    }

                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return ald;

        }


        @Override
        protected void onPostExecute(Alldata alldata) {
             arrlist = alldata.articles;
           final int last=arrlist.size();
               final TextView t1 = (TextView) findViewById(R.id.NewsTitle);
                final TextView t2 = (TextView) findViewById(R.id.Publish);
                final TextView t3 = (TextView) findViewById(R.id.Description);
                final TextView t4 = (TextView) findViewById(R.id.count);

                t1.setText((CharSequence) alldata.articles.get(0).title);
                t2.setText(alldata.articles.get(0).publishedat);
                t3.setText(alldata.articles.get(0).description);
                t4.setText(pc+"of" +last);

            String s1 = arrlist.get(c).urltoimage;
            ImageView iv = findViewById(R.id.imageView);
            Picasso.get().load(s1).into(iv);

            ImageView next=findViewById(R.id.imageView2);
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (c==last-1)
                    {
                        c=0;
                        pc=1;
                    }
                    else {
                        c++;
                        pc++;
                    }

                    t1.setText((CharSequence) arrlist.get(c).title);
                    t2.setText(arrlist.get(c).publishedat);
                    t3.setText(arrlist.get(c).description);
                    String s1 = arrlist.get(c).urltoimage;
                    ImageView iv = findViewById(R.id.imageView);
                    Picasso.get().load(s1).into(iv);
                    t4.setText(pc+"of" +last);
                }
            });

            ImageView prev=findViewById(R.id.imageView3);
            prev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (c==0)
                    {
                        c=last-1;
                        pc=last;
                    }
                    else {
                        c--;
                        pc--;
                    }
                    t1.setText((CharSequence) arrlist.get(c).title);
                    t2.setText(arrlist.get(c).publishedat);
                    t3.setText(arrlist.get(c).description);
                    String s1 = arrlist.get(c).urltoimage;
                    ImageView iv = findViewById(R.id.imageView);
                    Picasso.get().load(s1).into(iv);
                    t4.setText(pc+"of" +last);

                }
            });


        }
    }

}
