package com.example.a8001100226_midterm;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String TDD_KEY="TDD";
        SeekBar seekBar=findViewById(R.id.seekBar);
        Button search;
        final TextView limit;
        limit=findViewById(R.id.SeekLimit);
            seekBar.setMax(25);
           seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
               @Override
               public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                   if(progress < 5)
                   {
                       seekBar.setProgress(5);
                       limit.setText(String.valueOf(5));

                   }
                   else if(progress < 26)
                   {
                       seekBar.setProgress(progress);
                      limit.setText(String.valueOf(progress));
                   }
               }

               @Override
               public void onStartTrackingTouch(SeekBar seekBar) {

               }

               @Override
               public void onStopTrackingTouch(SeekBar seekBar) {

               }
           });
       final String strLimit = (limit.getText().toString().trim());
           search=findViewById(R.id.Search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tv;
               tv=findViewById(R.id.SongSearch);
                CharSequence song=tv.getText();
                RadioGroup rg=findViewById(R.id.radiogroup);
                int selectid=rg.getCheckedRadioButtonId();
                if (selectid==1) {
                    new getresults().execute("http://api.musixmatch.com/ws/1.1/track.search?apikey=7414d9c4ff7875cfc1db51d007b2bd07&q=" + song + "&s_artist_rating=desc&page_size=" + strLimit);
                }
                else
                {
                    new getresults().execute("http://api.musixmatch.com/ws/1.1/track.search?apikey=7414d9c4ff7875cfc1db51d007b2bd07&q=" + song + "&s_track_rating=desc&page_size=" + strLimit);
                }
            }
        });

    }

    public class getresults extends AsyncTask<String,Integer, ArrayList>
    {

        @Override
        protected ArrayList doInBackground(String... strings) {

                HttpURLConnection connection = null;
                BufferedReader reader;
                ArrayList <Track_Details> arrlist=new ArrayList<>();

                try {
                    URL url = new URL(strings[0]);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.connect();
                    if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        String Json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                        JSONObject root=new JSONObject(Json);
                        JSONObject root1=root.getJSONObject("body");
                        JSONArray jarray=root1.getJSONArray("track_list");
                        for (int i=0;i<jarray.length();i++)
                        {
                            JSONObject jsobject1=jarray.getJSONObject(i);
                            Track_Details td=new Track_Details();

                            td.track_name= jsobject1.getString("track_name");
                            td.album_name=jsobject1.getString("album_name");
                            td.artist_name=jsobject1.getString("artist_name");
                            td.updated_time=jsobject1.getString("updated_time");
                            td.track_share_url=jsobject1.getString("track_share_url");

                            arrlist.add(td);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return arrlist;
            }

        @Override
        protected void onPostExecute(final ArrayList arrlist) {

            ListView listView=(ListView) findViewById(R.id.listview);
            layout_adapter adapter= new layout_adapter(MainActivity.this,R.layout.listview_layout,arrlist);
            listView.setAdapter(adapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                                @Override
                                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                                    Track_Details td=new Track_Details();
                                                   td  = (Track_Details) arrlist.get(position);
                                                   String URL=td.track_share_url;
                                                    Intent i=new Intent(Intent.ACTION_VIEW);
                                                    i.setData(Uri.parse(URL));
                                                    startActivity(i);
                                                }
                                            });



        }
    }


}



