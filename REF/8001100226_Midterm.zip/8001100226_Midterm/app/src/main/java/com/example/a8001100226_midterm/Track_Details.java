package com.example.a8001100226_midterm;

public class Track_Details {

    String track_name,album_name,artist_name,updated_time,track_share_url;

    public Track_Details() {
    }

    @Override
    public String toString() {
        return "Track_Details{" +
                "track_name='" + track_name + '\'' +
                ", album_name='" + album_name + '\'' +
                ", artist_name='" + artist_name + '\'' +
                ", updated_time='" + updated_time + '\'' +
                ", track_share_url='" + track_share_url + '\'' +
                '}';
    }
}
