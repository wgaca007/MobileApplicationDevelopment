package com.example.a8001100226_midterm;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class layout_adapter extends ArrayAdapter<Track_Details> {
    public layout_adapter(@NonNull Context context, int resource, @NonNull List<Track_Details> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position,View convertView, @NonNull ViewGroup parent) {

        Track_Details track_details= (Track_Details) getItem(position);
        if (convertView==null)
        {
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.listview_layout,parent,false);
        }

        TextView tv1,tv2,tv3,tv4;
        tv1=convertView.findViewById(R.id.Track_input);
        tv2=convertView.findViewById(R.id.artist_input);
        tv3=convertView.findViewById(R.id.Date_input);
        tv4=convertView.findViewById(R.id.album_input);

        tv1.setText(track_details.track_name);
        tv2.setText(track_details.artist_name);
        tv3.setText(track_details.updated_time);
        tv4.setText(track_details.album_name);

        return convertView;
    }
}
