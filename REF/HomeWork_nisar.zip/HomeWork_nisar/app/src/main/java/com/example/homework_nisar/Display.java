package com.example.homework_nisar;

import java.io.Serializable;

public class Display implements Serializable {

    String YOURL,TRACK,GENRE;

    public Display() {
    }

    @Override
    public String toString() {
        return "Display{" +
                "YOURL='" + YOURL + '\'' +
                ", TRACK='" + TRACK + '\'' +
                ", GENRE='" + GENRE + '\'' +
                '}';
    }
}

