package com.example.homework_nisar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class DisplayData extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_data);

        Track_Details track_details=new Track_Details();
        track_details= (Track_Details) getIntent().getExtras().getSerializable(MainActivity.TDD_KEY);
        Log.d("DEMO","CLicked" + track_details.YOURL);

    }
}
