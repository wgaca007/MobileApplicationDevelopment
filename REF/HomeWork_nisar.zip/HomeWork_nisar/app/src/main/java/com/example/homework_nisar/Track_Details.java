package com.example.homework_nisar;

import java.io.Serializable;

class Track_Details implements Serializable {

    String Artist,Price,Date,Track,YOURL,GENRE;


    public Track_Details() {
    }

    @Override
    public String toString() {
        return "Track_Details{" +
                "Artist='" + Artist + '\'' +
                ", Price='" + Price + '\'' +
                ", Date='" + Date + '\'' +
                ", Track='" + Track + '\'' +
                ", YOURL='" + YOURL + '\'' +
                ", GENRE='" + GENRE + '\'' +
                '}';
    }
}
