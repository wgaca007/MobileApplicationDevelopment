package com.example.homework_nisar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;

public class layout_adapter extends ArrayAdapter<Track_Details> {
    public layout_adapter(@NonNull Context context, int resource, @NonNull List<Track_Details> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @androidx.annotation.Nullable View convertView, @NonNull ViewGroup parent) {

        Track_Details track_details= (Track_Details) getItem(position);
         if (convertView==null)
         {
             convertView= LayoutInflater.from(getContext()).inflate(R.layout.listview_layout,parent,false);
         }

        TextView tv1,tv2,tv3,tv4;
         tv1=convertView.findViewById(R.id.Track_input);
         tv2=convertView.findViewById(R.id.Input_date);
         tv3=convertView.findViewById(R.id.Input_price);
         tv4=convertView.findViewById(R.id.Track_input);

         tv1.setText(track_details.Track);
         tv2.setText(track_details.Date);
         tv3.setText(track_details.Price);
         tv4.setText(track_details.Track);

        return convertView;
    }
}
