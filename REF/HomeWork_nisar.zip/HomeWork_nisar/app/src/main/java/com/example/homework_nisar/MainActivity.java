package com.example.homework_nisar;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    static String TDD_KEY="TDD";
    ArrayList<Track_Details> arrlist=new ArrayList<>();

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        setTitle("Itunes Music Search");
        Button button=findViewById(R.id.search_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new itunes().execute("https://itunes.apple.com/search?term=<Arijit+Singh>&limit=25");

            }
        });



        }


    class itunes extends AsyncTask<String,Integer,ArrayList>
    {
        @Override
        protected void onPostExecute(final ArrayList arrlist) {
            listView=(ListView) findViewById(R.id.list_view);
            layout_adapter adapter= new layout_adapter(MainActivity.this,R.layout.listview_layout,arrlist);
            listView.setAdapter(adapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent i=new Intent(MainActivity.this,DisplayData.class);
                    i.putExtra(TDD_KEY, (Serializable) arrlist.get(position));
                    startActivity(i);
                }
            });

        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected ArrayList<Track_Details> doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader;


            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String Json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    JSONObject root=new JSONObject(Json);
                    JSONArray jarray=root.getJSONArray("results");
                    for (int i=0;i<jarray.length();i++)
                    {
                        JSONObject jsobject1=jarray.getJSONObject(i);
                        Track_Details td=new Track_Details();

                        td.Artist= jsobject1.getString("artistName");
                        td.Price=jsobject1.getString("trackPrice");
                        td.Track=jsobject1.getString("trackName");
                        td.Date=jsobject1.getString("releaseDate");
                        td.YOURL=jsobject1.getString("artworkUrl100");
                        td.GENRE=jsobject1.getString("primaryGenreName");
                        arrlist.add(td);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return arrlist;
        }

            }
}
