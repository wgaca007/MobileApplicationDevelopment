package com.example.group19_hw03;

import android.os.AsyncTask;
import android.view.View;
import android.widget.ProgressBar;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class GetSearchResults extends AsyncTask<String,Void, ArrayList<TuneDetails>> {

    SetTuneDetails iTune;


    public GetSearchResults(SetTuneDetails iTune) {
        this.iTune = iTune;

    }

    @Override
    protected ArrayList<TuneDetails> doInBackground(String... strings) {

       HttpURLConnection connection = null;
                ArrayList<TuneDetails> arr = null;
                TuneDetails tuneDetails = null;
                try {
                    URL url = new URL(strings[0]);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.connect();
                    if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        String Json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                        arr = new ArrayList<TuneDetails>();
                        JSONObject root = new JSONObject(Json);

                        JSONArray jArray = root.getJSONArray("results");
                        if(jArray.length()>0){
                            for (int k = 0; k < jArray.length(); k++) {
                                JSONObject jsobj1 = jArray.getJSONObject(k);
                                tuneDetails = new TuneDetails();
                                tuneDetails.artistName = jsobj1.getString("artistName");
                                tuneDetails.collectionName = jsobj1.getString("collectionName");
                                tuneDetails.collectionPrice = jsobj1.getDouble("collectionPrice");
                                tuneDetails.trackPrice = jsobj1.getDouble("trackPrice");
                                tuneDetails.primaryGenreName = jsobj1.getString("primaryGenreName");
                                tuneDetails.trackName = jsobj1.getString("trackName");
                                tuneDetails.releaseDate = jsobj1.getString("releaseDate");
                                tuneDetails.artworkUrl100 = jsobj1.getString("artworkUrl100");
                                arr.add(tuneDetails);

                            }


                        }

                    }

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            return arr;

    }

    @Override
    protected void onPostExecute(ArrayList<TuneDetails> tuneDetails) {
        iTune.setTunesIntoListView(tuneDetails);

    }

    public interface SetTuneDetails{
        public void setTunesIntoListView(ArrayList<TuneDetails> tuneDetails);

    }
}
