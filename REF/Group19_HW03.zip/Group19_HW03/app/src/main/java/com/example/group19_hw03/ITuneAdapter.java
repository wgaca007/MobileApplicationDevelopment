package com.example.group19_hw03;

import android.arch.core.internal.SafeIterableMap;
import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class ITuneAdapter extends ArrayAdapter<TuneDetails> {
    public ITuneAdapter(Context context, int resource, ArrayList<TuneDetails> objects) {
        super(context, resource, objects);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        TuneDetails tuneDetails = getItem(position);
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.itunes, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.txtTrackName = (TextView) convertView.findViewById(R.id.txtTrackName);
            viewHolder.txtPriceValue = (TextView) convertView.findViewById(R.id.txtPriceValue);
            viewHolder.txtArtistName = (TextView) convertView.findViewById(R.id.txtArtistName);
            viewHolder.txtDateValue = (TextView) convertView.findViewById(R.id.txtDateValue);
            convertView.setTag(viewHolder);
        }


        viewHolder = (ViewHolder) convertView.getTag();
        viewHolder.txtTrackName.setText(tuneDetails.trackName);
        viewHolder.txtPriceValue.setText(String.valueOf(tuneDetails.trackPrice));
        viewHolder.txtArtistName.setText(tuneDetails.artistName);
        Log.d("demo",tuneDetails.releaseDate);

        Date string = null;
        try {

            string = new SimpleDateFormat("MM-DD-YYYY").parse(tuneDetails.releaseDate.split("T")[0].toString());

            Log.d("test",String.valueOf(string.getDate()));
        } catch (ParseException e) {
            e.printStackTrace();
        }



        viewHolder.txtDateValue.setText(String.valueOf(string));


        return convertView;
    }


    private static class ViewHolder {
        TextView txtTrackName, txtArtistName, txtPriceValue, txtDateValue;
    }
}
