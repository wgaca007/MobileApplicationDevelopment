package com.example.group19_hw03;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class Second_Activity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondlayout);
        setTitle("iTunes Music Search");

        if(getIntent() != null)
        {
            if(getIntent().getExtras().getSerializable("TrackDetails") != null){
                TuneDetails tuneDetails = new TuneDetails();
                tuneDetails = (TuneDetails) getIntent().getExtras().getSerializable("TrackDetails");
                TextView txtTrack = (TextView) findViewById(R.id.txtTrack);
                TextView txtGenre = (TextView) findViewById(R.id.txtGenre);
                TextView txtArtist = (TextView) findViewById(R.id.txtArtist);
                TextView txtAlbum = (TextView) findViewById(R.id.txtAlbum);
                TextView txtTrackPrice = (TextView) findViewById(R.id.txtTrackPrice);
                TextView txtAlbumPrice = (TextView) findViewById(R.id.txtAlbumPrice);


                Picasso.get().load(tuneDetails.artworkUrl100).into((ImageView) findViewById(R.id.imageView2));

                txtTrack.setText("Track: "+ tuneDetails.trackName);
                txtGenre.setText("Genre: "+ tuneDetails.primaryGenreName);
                txtArtist.setText("Artist: "+ tuneDetails.artistName);
                txtAlbum.setText("Album: "+ tuneDetails.collectionName);
                txtTrackPrice.setText("Track Price: "+ tuneDetails.trackPrice);
                txtAlbumPrice.setText("Album Price: "+ tuneDetails.collectionPrice);
            }
            findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
        }

    }
}
