package com.example.group19_hw03;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements GetSearchResults.SetTuneDetails {
    TextView txtLimit;
    EditText editText;
    ProgressBar pb;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("iTunes Music Search");
        pb = (ProgressBar)findViewById(R.id.progressBar);
        pb.setVisibility(View.GONE);
        final SeekBar seekBar = (SeekBar) findViewById(R.id.sbLimit);
        txtLimit = (TextView) findViewById(R.id.txtLimit);
        editText = (EditText) findViewById(R.id.txtKeyword);


        seekBar.setMax(30);
        seekBar.setProgress(10);

        txtLimit.setText("10");


        findViewById(R.id.btnSearch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pb.setVisibility(View.VISIBLE);
                String searchString = "", strLimit = "";
                    txtLimit = (TextView) findViewById(R.id.txtLimit);
                    editText = (EditText) findViewById(R.id.txtKeyword);
                    searchString = editText.getText().toString().toLowerCase().trim().replaceAll(" ", "+");
                    strLimit = txtLimit.getText().toString().trim();


                new GetSearchResults(MainActivity.this).execute("https://itunes.apple.com/search?term=" + searchString + "&limit=" + strLimit);
                pb.setVisibility(View.GONE);
            }
        });

        findViewById(R.id.btnReset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtLimit.setText("10");
                seekBar.setProgress(10);
                editText.setText("");
            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(progress < 10)
                {
                    seekBar.setProgress(10);
                    txtLimit.setText(String.valueOf(10));
                }
               else if(progress < 31)
                {
                    seekBar.setProgress(progress);
                    txtLimit.setText(String.valueOf(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    @Override
    public void setTunesIntoListView(final ArrayList<TuneDetails> tuneDetails) {

        ListView listView = (ListView) findViewById(R.id.ListView);

        ITuneAdapter iTuneAdapter = new ITuneAdapter(MainActivity.this, R.layout.itunes, tuneDetails);

        listView.setAdapter(iTuneAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("demo", "Clicked item : " + position);
                Intent intent = new Intent(MainActivity.this,Second_Activity.class);
                intent.putExtra("TrackDetails",tuneDetails.get(position));
                startActivity(intent);
            }
        });
    }


}
