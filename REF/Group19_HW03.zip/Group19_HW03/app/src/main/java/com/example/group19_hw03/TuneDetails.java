package com.example.group19_hw03;

import java.io.Serializable;

public class TuneDetails implements Serializable {
    String trackName, primaryGenreName, artistName, collectionName, releaseDate, artworkUrl100;
    double trackPrice, collectionPrice;

    @Override
    public String toString() {
        return "TuneDetails{" +
                "trackName='" + trackName + '\'' +
                ", primaryGenreName='" + primaryGenreName + '\'' +
                ", artistName='" + artistName + '\'' +
                ", collectionName='" + collectionName + '\'' +
                ", releaseDate='" + releaseDate + '\'' +
                ", trackPrice=" + trackPrice +
                ", collectionPrice=" + collectionPrice +
                '}';
    }
}
