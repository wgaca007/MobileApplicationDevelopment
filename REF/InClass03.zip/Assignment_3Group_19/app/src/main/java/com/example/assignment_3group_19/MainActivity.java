package com.example.assignment_3group_19;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    public final static String STUDENT_KEY = "Student", IMAGE = "AVATAR", IMAGE_ID = "imgID";
    public static final int REQ_CODE = 1001;
    public static String checkedDept = "CS";
    public static final Student student = new Student();
    byte[] studentAvatar;
    RadioGroup rg;
    EditText first_name, last_name, student_id;
    ImageView img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("My Profile");

        first_name = (EditText) findViewById(R.id.editText2);
        last_name = (EditText) findViewById(R.id.editText3);
        student_id = (EditText) findViewById(R.id.editText4);
        rg = (RadioGroup) findViewById(R.id.radioGroupDept);
        img = (ImageView) findViewById(R.id.mainImageView);




        if (getIntent() != null) {
            if (getIntent().getExtras() != null) {
                Student stu = new Student();
                stu = (Student) getIntent().getExtras().getSerializable("Student");
                first_name.setText(stu.first_name);
                last_name.setText(stu.last_name);
                student_id.setText(stu.student_id);
                for (int i = 0; i < rg.getChildCount(); i++) {
                    RadioButton radioButton = (RadioButton) rg.getChildAt(i);
                    if (radioButton.getText().toString().equalsIgnoreCase(stu.department)) {
                        radioButton.setChecked(true);
                    } else {
                        radioButton.setChecked(false);
                    }
                }

                Bitmap bmp = BitmapFactory.decodeByteArray(stu.img, 0, stu.img.length);
                studentAvatar = stu.img;
                img.setImageBitmap(bmp);
                img.setTag(stu.imgID);

            } else {
                img.setTag(R.drawable.select_image);
            }
        }


        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this, SecondActivity.class);
                startActivityForResult(i, REQ_CODE);

            }

        });


        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = (RadioButton) findViewById(checkedId);
                checkedDept = rb.getText().toString();
                Log.d("assignment3", "checked dept : " + checkedDept);
            }
        });


        findViewById(R.id.button_save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {


                    EditText firstName = (EditText) findViewById(R.id.editText2);
                    EditText lastName = (EditText) findViewById(R.id.editText3);
                    EditText studentID = (EditText) findViewById(R.id.editText4);




                    Object obj = img.getTag();
                    int imgTag = (int) obj;
                    if (imgTag == R.drawable.select_image) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Please select an avatar.", Toast.LENGTH_SHORT);
                        toast.show();
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        return;
                    } else {
                        student.imgID = obj;
                        student.img = studentAvatar;
                    }

                    student.img = studentAvatar;

                    if (firstName.getText().toString().isEmpty()) {
                        firstName.setError("Please enter First Name.");
                        return;
                    } else {
                        student.first_name = firstName.getText().toString();
                    }

                    if (lastName.getText().toString().isEmpty()) {
                        lastName.setError("Please enter Last Name.");
                        return;
                    } else {
                        student.last_name = lastName.getText().toString();
                    }

                    if (studentID.getText().toString().isEmpty()) {
                        studentID.setError("Please enter Student ID.");
                        return;
                    } else {
                        if (studentID.getText().toString().length() > 9 || studentID.getText().toString().length() < 9) {
                            studentID.setError("Please enter a valid 9-digit Student ID.");
                            return;
                        } else {
                            student.student_id = studentID.getText().toString();
                        }
                    }

                    if (checkedDept.toString().isEmpty()) {
                        Toast toast = Toast.makeText(getApplicationContext(), "Please select a department.", Toast.LENGTH_SHORT);
                        toast.show();
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        return;
                    } else {
                        student.department = checkedDept;
                    }


                    Intent ThirdActivity = new Intent("com.example.assignment_3group_19.intent.action.VIEW");
                    ThirdActivity.putExtra(STUDENT_KEY, student);
                    startActivity(ThirdActivity);
                    finish();
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == REQ_CODE) {
            if (data.getExtras().containsKey(IMAGE) && data.getExtras().containsKey(IMAGE_ID)) {
                byte[] b = data.getByteArrayExtra("AVATAR");
                Bitmap bmp = BitmapFactory.decodeByteArray(b, 0, b.length);
                studentAvatar = b;
                
                img.setImageBitmap(bmp);
                img.setTag(data.getExtras().getInt("imgID"));

            }

        }


    }
}
