package com.example.assignment_3group_19;

import android.graphics.Bitmap;

import java.io.Serializable;

public class Student implements Serializable {


    String first_name;
    String last_name;
    String student_id;
    String department;
    byte[] img;
    Object imgID;

    @Override
    public String toString() {
        return first_name + ' ' + last_name ;
    }
}
