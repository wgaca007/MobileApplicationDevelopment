package com.example.assignment_3group_19;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;

public class SecondActivity extends AppCompatActivity {
    final static int REQ_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        setTitle("Select Avatar");

        findViewById(R.id.imageView2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImgClicked(v.getId());
            }
        });

        findViewById(R.id.imageView3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImgClicked(v.getId());
            }
        });

        findViewById(R.id.imageView4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImgClicked(v.getId());
            }
        });

        findViewById(R.id.imageView5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImgClicked(v.getId());
            }
        });

        findViewById(R.id.imageView6).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImgClicked(v.getId());
            }
        });

        findViewById(R.id.imageView7).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImgClicked(v.getId());
            }
        });

    }

    protected void getImgClicked(int id) {
        ImageView img;Drawable drw;int imgID;



        if (id == R.id.imageView2) {
            img = (ImageView) findViewById(R.id.imageView2);
            drw = getResources().getDrawable(R.drawable.avatar_f_1);
            imgID = R.drawable.avatar_f_1;
        }
        else if(id == R.id.imageView3) {
            img = (ImageView) findViewById(R.id.imageView3);
            drw = getResources().getDrawable(R.drawable.avatar_m_1);
            imgID = R.drawable.avatar_m_1;
        }
        else if(id == R.id.imageView4) {
            img = (ImageView) findViewById(R.id.imageView4);
            drw = getResources().getDrawable(R.drawable.avatar_f_2);
            imgID = R.drawable.avatar_f_2;
        }
        else if(id == R.id.imageView5) {
            img = (ImageView) findViewById(R.id.imageView5);
            drw = getResources().getDrawable(R.drawable.avatar_m_2);
            imgID = R.drawable.avatar_m_2;
        }
        else if(id == R.id.imageView6) {
            img = (ImageView) findViewById(R.id.imageView6);
            drw = getResources().getDrawable(R.drawable.avatar_f_3);
            imgID = R.drawable.avatar_f_3;
        }
        else {
            img = (ImageView) findViewById(R.id.imageView7);
            drw = getResources().getDrawable(R.drawable.avatar_m_3);
            imgID = R.drawable.avatar_m_3;
        }


        Intent i = new Intent(SecondActivity.this, MainActivity.class);
        Bitmap bmp = ((BitmapDrawable) drw).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();

        i.putExtra(MainActivity.IMAGE, b);
        i.putExtra(MainActivity.IMAGE_ID, imgID);
        setResult(RESULT_OK, i);

        finish();
    }

}




