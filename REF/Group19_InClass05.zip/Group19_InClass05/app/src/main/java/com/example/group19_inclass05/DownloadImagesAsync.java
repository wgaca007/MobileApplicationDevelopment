package com.example.group19_inclass05;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DownloadImagesAsync extends AsyncTask<String, Void, Bitmap> {

    ISetImage Ism;

    public DownloadImagesAsync(ISetImage ism) {
        Ism = ism;
    }

    @Override
    protected void onPreExecute() {
        Ism.displayProgressbar();
    }

    @Override
    protected Bitmap doInBackground(String... strings) {

        HttpURLConnection connection = null;
        Bitmap bitmap = null;
        try {
            URL url = new URL(strings[0]);
            Log.d("test",strings[0]);
            connection = (HttpURLConnection) url.openConnection();

            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                bitmap = BitmapFactory.decodeStream(connection.getInputStream());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            connection.disconnect();
        }
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        Ism.setImage(bitmap);
    }

    public interface ISetImage{
        public void setImage(Bitmap bmp);
        public void displayProgressbar();
    }

}
