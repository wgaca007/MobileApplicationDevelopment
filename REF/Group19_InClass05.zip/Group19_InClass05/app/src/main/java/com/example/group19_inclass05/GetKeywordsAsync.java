package com.example.group19_inclass05;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.commons.io.IOUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class GetKeywordsAsync extends AsyncTask<String,Void,String> {

    SetKeywords skwrds;

    public GetKeywordsAsync(SetKeywords str)
    {
        this.skwrds = str;
    }

    @Override
    protected String doInBackground(String... strings) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        String result = null;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            URL url = new URL(strings[0]);
            Log.d("test",strings[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                    Log.d("test2",stringBuilder.toString());
                }
                Log.d("test2",stringBuilder.toString());
                return stringBuilder.toString();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            connection.disconnect();
        }

        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        skwrds.setKeywordsIntoDialog(s);
    }

    public interface SetKeywords
    {
        public void setKeywordsIntoDialog(String str);
    }
}
