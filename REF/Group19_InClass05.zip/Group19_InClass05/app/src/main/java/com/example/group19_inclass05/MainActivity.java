package com.example.group19_inclass05;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity
        implements GetKeywordsAsync.SetKeywords, GetImageAsync.IGetImageLinksArray, DownloadImagesAsync.ISetImage {
    String[] strArr;
    Button btnGO;
    ImageView img, imgPrev, imgNext;
    ArrayList<String> imgLinks = new ArrayList<String>();
    int currImgIndex = -1;
    TextView edt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Main Activity");
        btnGO = (Button) findViewById(R.id.btnGO);
        btnGO.setEnabled(false);
        imgPrev = (ImageView) findViewById(R.id.ivwPrev);
        imgNext = (ImageView) findViewById(R.id.ivwNext);
        edt = (TextView) findViewById(R.id.txtImage);


        edt.setEnabled(false);
        imgPrev.setEnabled(false);
        imgPrev.setClickable(false);
        imgNext.setEnabled(false);
        imgNext.setClickable(false);




        if (isConnected()) {
            edt.setEnabled(true);
            new GetKeywordsAsync(MainActivity.this).execute("http://dev.theappsdr.com/apis/photos/keywords.php");

            btnGO.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle(getResources().getString(R.string.lblkeyword))
                            .setCancelable(false)
                            .setItems(strArr, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    TextView pt = (TextView) findViewById(R.id.txtImage);
                                    pt.setText(strArr[which]);
                                    new GetImageAsync(MainActivity.this).execute("http://dev.theappsdr.com/apis/photos/index.php?keyword=" + strArr[which]);
                                }
                            });

                    builder.create().show();

                }
            });
        }
        else{
            Toast.makeText(MainActivity.this, "No Internet Connection.", Toast.LENGTH_SHORT).show();
        }

        imgNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currImgIndex == imgLinks.size() - 1 )
                    currImgIndex = 0;
                else
                    currImgIndex += 1;

                if (currImgIndex < imgLinks.size()) {
                    new DownloadImagesAsync(MainActivity.this).execute(imgLinks.get(currImgIndex));

                }

            }
        });

        imgPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (currImgIndex == imgLinks.size())
//                    currImgIndex -= 1;
                if (currImgIndex == 0)
                    currImgIndex = imgLinks.size()-1;
                else
                    currImgIndex -= 1;

                new DownloadImagesAsync(MainActivity.this).execute(imgLinks.get(currImgIndex));

            }
        });


    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }


    @Override
    public void setKeywordsIntoDialog(String str) {
        if (str != null) {
            strArr = str.split(";");
            btnGO.setEnabled(true);

        } else {
            strArr[0] = new String();
            strArr[0] = "No Results Found.";
            btnGO.setEnabled(true);

        }

    }


    @Override
    public void StoreImageLinksArray(ArrayList<String> arr) {
        if (arr !=null && arr.size() > 0) {

            imgLinks = arr;
            currImgIndex = 0;
            new DownloadImagesAsync(MainActivity.this).execute(arr.get(currImgIndex));
            imgPrev = (ImageView) findViewById(R.id.ivwPrev);
            imgNext = (ImageView) findViewById(R.id.ivwNext);

            if (arr.size() > 1) {
                imgPrev.setEnabled(true);
                imgPrev.setClickable(true);
                imgNext.setEnabled(true);
                imgNext.setClickable(true);

            }
        }
        else
        {
            img = (ImageView) findViewById(R.id.ivwDisplayImage);
            img.setImageBitmap(null);
            Toast.makeText(MainActivity.this, "No Images Found.", Toast.LENGTH_SHORT).show();
            imgLinks = null;
            imgPrev.setEnabled(false);
            imgPrev.setClickable(false);
            imgNext.setEnabled(false);
            imgNext.setClickable(false);
        }
    }

    @Override
    public void setImage(Bitmap bmp) {
        img = (ImageView) findViewById(R.id.ivwDisplayImage);
        ProgressBar pb = (ProgressBar) findViewById(R.id.progressBar);
        pb.setVisibility(View.INVISIBLE);
        img.setVisibility(View.VISIBLE);
        img.setImageBitmap(bmp);
    }

    @Override
    public void displayProgressbar() {
        img = (ImageView) findViewById(R.id.ivwDisplayImage);
        ProgressBar pb = (ProgressBar) findViewById(R.id.progressBar);

        img.setVisibility(View.INVISIBLE);
        pb.setVisibility(View.VISIBLE);
    }
}
