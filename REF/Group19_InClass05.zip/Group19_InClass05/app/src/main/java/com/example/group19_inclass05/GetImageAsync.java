package com.example.group19_inclass05;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.commons.io.IOUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class GetImageAsync extends AsyncTask<String, Void, ArrayList<String>> {

    IGetImageLinksArray iG;


    public GetImageAsync(IGetImageLinksArray iG) {
        this.iG = iG;
    }

    @Override
    protected ArrayList<String> doInBackground(String... strings) {
        HttpURLConnection connection = null;
        BufferedReader reader;
        ArrayList<String> arr = null;
        try {
            URL url = new URL(strings[0]);
            Log.d("test",strings[0]);
            connection = (HttpURLConnection) url.openConnection();

            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = "";
                arr = new ArrayList<String>();
                while ((line = reader.readLine()) != null) {

                    Log.d("test2", line);
                    arr.add(line);
                }


            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            connection.disconnect();
        }

        return arr;
    }

    @Override
    protected void onPostExecute(ArrayList<String> strings) {
        iG.StoreImageLinksArray(strings);
    }

    public interface IGetImageLinksArray{
        public void StoreImageLinksArray(ArrayList<String> arr);
    }
}
