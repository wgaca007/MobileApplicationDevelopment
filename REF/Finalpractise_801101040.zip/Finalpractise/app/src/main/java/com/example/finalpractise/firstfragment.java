package com.example.finalpractise;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class firstfragment extends Fragment {

    private OnFragmentInteractionListener mListener;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (firstfragment.OnFragmentInteractionListener) context;
    }

    ArrayList<Dealsobj> arrayList=new ArrayList<>();
    ArrayList<Placesobj> arrList=new ArrayList<>();
    public String loadJSONFromAsset() {
        String json = null;
        Context context = getContext();
        try {
            InputStream is = context.getAssets().open("jsonToImport.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return json;
    }


    public firstfragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_firstfragment, container, false);

        String JSON = loadJSONFromAsset();
        try {
            JSONObject root = new JSONObject(JSON);
            JSONObject root1=root.getJSONObject("Deals");
            JSONObject place1=root.getJSONObject("Places");
            for (int i=1;i<=20;i++)
            {

                Dealsobj dobj=new Dealsobj();
                Placesobj pobj=new Placesobj();
                JSONObject place2=place1.getJSONObject("Place"+i);
                JSONObject root2=root1.getJSONObject("Deal"+i);
                JSONObject root3=root2.getJSONObject("Location");
                String place=root2.getString("Place");
                dobj.placename=place;
                String pcity=place2.getString("City");
                pobj.placename=pcity;
                String dur=root2.getString("Duration");
                dobj.duration=dur;
                String cost=root2.getString("Cost");
                dobj.cost=cost;
                Double lat=root3.getDouble("Lat");
                dobj.lat=lat;
                Double longi=root3.getDouble("Lon");
                dobj.longi=longi;
                arrayList.add(dobj);
                arrList.add(pobj);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }


        view.findViewById(R.id.getdeal).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.gotoshow(arrayList);
            }
        });


        view.findViewById(R.id.createtrip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.createtripfrag(arrList);
            }
        });
        return view;

    }

    public interface OnFragmentInteractionListener
    {
        void gotoshow(ArrayList<Dealsobj> arrayList);
        void createtripfrag(ArrayList<Placesobj> arrList);
    }

}
