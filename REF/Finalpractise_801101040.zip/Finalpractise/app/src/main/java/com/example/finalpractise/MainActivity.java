package com.example.finalpractise;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements firstfragment.OnFragmentInteractionListener,showdeals.OnFragmentInteractionListener{



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Container, new firstfragment(), "first")
                .commit();
    }

    @Override
    public void gotoshow(ArrayList<Dealsobj> arrayList) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Container, new showdeals(arrayList), "first")
                .commit();
    }

    @Override
    public void createtripfrag(ArrayList<Placesobj> arrList) {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Container, new createtripfrag(arrList), "first")
                .commit();

    }

    @Override
    public void addtriptofirebase(Dealsobj dobj) {

        DatabaseReference dbref;
        dbref = FirebaseDatabase
                .getInstance()
                .getReference("TripList");

        Log.d("demo","Inserting into firebase");
        Log.d("demo",dobj.toString());

        dbref.push().setValue(dobj);
    }
}
