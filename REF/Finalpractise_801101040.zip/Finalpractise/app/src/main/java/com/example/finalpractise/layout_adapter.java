package com.example.finalpractise;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class layout_adapter extends ArrayAdapter<Dealsobj> {

    //private adapterlistener mlistener;
    int flag;
    static Dealsobj dobj1=null;

    public layout_adapter(Context context, int resource,List<Dealsobj> objects) {
        super(context, resource, objects);
    }


    @NonNull
    @Override
    public View getView(int position,View convertView, @NonNull ViewGroup parent) {

        Dealsobj dobj= (Dealsobj) getItem(position);
        if (convertView==null)
        {
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.show_deals,parent,false);
        }

        TextView tv1,tv2,tv3;
        final RadioButton rb;
        rb=convertView.findViewById(R.id.radioButton);
        if(rb.isChecked()) {
            dobj1=new Dealsobj();
            dobj1=dobj;
            Log.d("demo",dobj1.toString());
        }

        tv1=convertView.findViewById(R.id.placename);
        tv2=convertView.findViewById(R.id.duration);
        tv3=convertView.findViewById(R.id.cost);

        tv1.setText(dobj.placename);
        tv2.setText(dobj.duration);
        tv3.setText(dobj.cost);


        return convertView;
    }

//    public interface adapterlistener{
//        void gotoshowdeals(Dealsobj dobj1);
//    }
}

