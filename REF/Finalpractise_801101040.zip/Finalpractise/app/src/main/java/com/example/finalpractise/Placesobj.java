package com.example.finalpractise;

public class Placesobj {

    String placename;
}
