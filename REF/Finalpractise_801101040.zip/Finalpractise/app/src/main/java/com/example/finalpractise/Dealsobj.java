package com.example.finalpractise;

public class Dealsobj {

    public String placename,duration,cost;
    public Double lat,longi;

    public Dealsobj() {
    }

    @Override
    public String toString() {
        return "Dealsobj{" +
                "placename='" + placename + '\'' +
                ", duration='" + duration + '\'' +
                ", cost='" + cost + '\'' +
                ", lat=" + lat +
                ", longi=" + longi +
                '}';
    }
}
