package com.example.finalpractise;


import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import static com.example.finalpractise.layout_adapter.dobj1;


/**
 * A simple {@link Fragment} subclass.
 */
@SuppressLint("ValidFragment")
public class showdeals extends Fragment {

    private OnFragmentInteractionListener mListener;
    ArrayList<Dealsobj> arrayList;
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (showdeals.OnFragmentInteractionListener) context;
    }

    @Override
    public void onAttachFragment(Fragment childFragment) {

    }

    Dealsobj dobject;

    public showdeals(Dealsobj dobject) {
        this.dobject = dobject;
    }

    @SuppressLint("ValidFragment")
    public showdeals(ArrayList<Dealsobj> arrayList) {
        this.arrayList = arrayList;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_showdeals, container, false);

        final ListView listView=view.findViewById(R.id.listview);
        layout_adapter adapter= new layout_adapter(getContext(),R.layout.show_deals,arrayList);
        listView.setAdapter(adapter);

        view.findViewById(R.id.addtotrip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.addtriptofirebase(dobj1);
            }
        });
        return view;
    }

//    @Override
//    public void gotoshowdeals(Dealsobj dobj) {
//     this.dobject=dobj;
//    }

    public interface OnFragmentInteractionListener{
        void addtriptofirebase(Dealsobj dobject);
    }

}
