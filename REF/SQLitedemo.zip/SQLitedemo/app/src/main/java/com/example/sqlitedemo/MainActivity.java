package com.example.sqlitedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.List;

public class MainActivity extends AppCompatActivity {


    DBManager dbManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbManager=new DBManager(this);
        dbManager.saveNote(new Note("NOte1","Text1"));
        dbManager.saveNote(new Note("NOte2","Text2"));
        dbManager.saveNote(new Note("NOte3","Text3"));

        List<Note> notes= dbManager.getALLNotes();

        Log.d("demooo",notes.toString());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbManager.close();
    }
}
