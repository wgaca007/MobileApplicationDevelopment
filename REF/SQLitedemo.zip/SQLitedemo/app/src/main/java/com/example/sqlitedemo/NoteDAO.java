package com.example.sqlitedemo;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class NoteDAO {
    private SQLiteDatabase db;

    public NoteDAO(SQLiteDatabase db) {
        this.db = db;
    }

    public long save(Note note)
    {
        ContentValues cv=new ContentValues();
        cv.put(NotesTable.COLUMN_SUBJECT,note.getSubject());
        cv.put(NotesTable.COLUMN_TEXT,note.getText());

        db.insert(NotesTable.TABLE_NAME,null,cv);
        return 0;
    }

    public boolean update(Note note)
    {
        ContentValues cv=new ContentValues();
        cv.put(NotesTable.COLUMN_SUBJECT,note.getSubject());
        cv.put(NotesTable.COLUMN_TEXT,note.getText());
        return db.update(NotesTable.TABLE_NAME,cv,NotesTable.COLUMN_ID + "=?" ,new String[]{note.get_id()+ ""} ) >0;
    }

    public boolean delete (Note note)
    {
        db.delete(NotesTable.TABLE_NAME,NotesTable.COLUMN_ID + "=?" ,new String[]{note.get_id()+ ""}) ;
        return false;
    }

    public Note get(long id)
    {
        Note note=null;
        Cursor c=db.query(true,NotesTable.TABLE_NAME,new String[]{NotesTable.COLUMN_ID,NotesTable.COLUMN_SUBJECT,NotesTable.COLUMN_TEXT},
                NotesTable.COLUMN_ID + "=?", new String[]{note.get_id()+ ""},null,null,null,null,null);


        if(c!=null && c.moveToFirst())
        {
            note=builtfromcursor(c);
            if(!c.isClosed())
            {
                c.close();
            }
        }
        return note;

    }

    public List<Note> getALLNotes()
    {

        List<Note> noteslist=new ArrayList<>();
        Cursor c=db.query(true,NotesTable.TABLE_NAME,new String[]{NotesTable.COLUMN_ID,NotesTable.COLUMN_SUBJECT,NotesTable.COLUMN_TEXT},
                null, null,null,null,null,null,null);

        if(c!=null && c.moveToFirst())
        {
           do {
               Note note=builtfromcursor(c);
               if(note!=null)
               {
                   noteslist.add(note);
               }

           }while(c.moveToNext());

            if(!c.isClosed())
            {
                c.close();
            }
        }

        return noteslist;
    }

    private Note builtfromcursor(Cursor c)
    {
        Note note=null;
        if (c!=null)
        {
            note=new Note();
            note.set_id(c.getLong(0));
            note.setSubject(c.getString(1));
            note.setText(c.getString(2));
        }

        return note;
    }
}
