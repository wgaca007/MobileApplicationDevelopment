package com.example.sqlitedemo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.List;

public class DBManager {

    private Context mContext;
    private DbOpenHelper dbhelper;
    private SQLiteDatabase db;
    private NoteDAO noteDAO;

    public DBManager(Context mContext) {
        this.mContext = mContext;
        dbhelper= new DbOpenHelper(mContext);
        db=dbhelper.getWritableDatabase();
        noteDAO=new NoteDAO(db);
    }

    public void close()
    {
        if (db!=null)
        {
            db.close();
        }
    }

    public NoteDAO getNoteDAO()
    {
        return this.noteDAO;
    }

    public long saveNote(Note note)
    {
        return this.noteDAO.save(note);
    }
    public boolean updatenote(Note note)
    {
        return this.noteDAO.update(note);
    }

    public boolean deletenode(Note note)
    {
        return this.noteDAO.delete(note);
    }

    public Note get(long id)
    {
        return this.noteDAO.get(id);
    }

    public List<Note> getALLNotes()
    {
        return this.noteDAO.getALLNotes();
    }
}
