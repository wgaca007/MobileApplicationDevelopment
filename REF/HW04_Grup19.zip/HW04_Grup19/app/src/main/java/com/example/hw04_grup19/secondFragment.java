package com.example.hw04_grup19;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class secondFragment extends Fragment {

//    private OnFragmentInteractionListener mListener;

    RecyclerView recycleView;
    Context cont;
    RecipesAdapter radapter;
    ArrayList<RecipeResult> arr = null;
    String url;

    public secondFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        cont = container.getContext();
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //if(mListener != null){
        recycleView = (RecyclerView) getActivity().findViewById(R.id.recyclerView2);
        recycleView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(cont);
        recycleView.setLayoutManager(layoutManager);

        new getrecipes().execute("http:// www.recipepuppy.com/api/?i=onions,garlic&q=omelet");


        //}
    }

//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
//    }
//
//    @Override
//    public void onDetach() {
//        super.onDetach();
//        mListener = null;
//    }
//
//    public interface OnFragmentInteractionListener {
//        // TODO: Update argument type and name
//        void onFragmentInteraction(Uri uri);
//    }


    public class getrecipes extends AsyncTask<String, Integer, ArrayList<RecipeResult>>
    {

        @Override
        protected ArrayList<RecipeResult> doInBackground(String... strings) {

            HttpURLConnection connection = null;

            RecipeResult rr = null;
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String Json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    arr = new ArrayList<RecipeResult>();
                    JSONObject root = new JSONObject(Json);

                    JSONArray jArray = root.getJSONArray("results");
                    if(jArray.length()>0){
                        for (int k = 0; k < jArray.length(); k++) {
                            JSONObject jsobj1 = jArray.getJSONObject(k);
                            rr = new RecipeResult();
                            // rr.artistName = jsobj1.getString("artistName");
                            rr.ing=jsobj1.getString("ingredients");
                            rr.url=jsobj1.getString("href");
                            rr.title=jsobj1.getString("title");
                            rr.image=jsobj1.getString("thumbnail");
                            arr.add(rr);

                        }


                    }

                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }


            return arr;

        }

        @Override
        protected void onPostExecute(ArrayList<RecipeResult> recipeResults) {
            radapter=new RecipesAdapter(recipeResults);
            recycleView.setAdapter(radapter);

        }
    }
}
