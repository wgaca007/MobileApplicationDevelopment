package com.example.hw04_grup19;

public class RecipeResult {

    String title,url,ing,image;

    @Override
    public String toString() {
        return super.toString();
    }

}
