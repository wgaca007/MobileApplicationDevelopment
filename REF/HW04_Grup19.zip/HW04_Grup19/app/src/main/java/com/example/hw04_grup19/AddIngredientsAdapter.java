package com.example.hw04_grup19;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.design.widget.FloatingActionButton;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class AddIngredientsAdapter extends RecyclerView.Adapter<AddIngredientsAdapter.MyViewHolder> {

    Context cont;
    ViewGroup VG;

    ArrayList<String> ingredients = new ArrayList<>();

    public AddIngredientsAdapter(Context con, ArrayList<String> ing) {
        this.cont = con;
        this.ingredients = ing;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        public FloatingActionButton btnAdd;

        public MyViewHolder(View itemView) {
            super(itemView);
            btnAdd = (FloatingActionButton) itemView.findViewById(R.id.btnAdd);
        }
    }


    @Override
    public AddIngredientsAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                                 int viewType) {
        VG = parent;

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.ingredients, null, false);


        MyViewHolder vh = new MyViewHolder(view);


        if (ingredients.size() > 1) {
            if (vh.getAdapterPosition() < ingredients.size() - 1) {
                vh.btnAdd.setImageResource(R.drawable.ic_close_black_24dp);
                vh.btnAdd.setTag("Close");
            } else if (vh.getAdapterPosition() == ingredients.size() - 1) {
                vh.btnAdd.setImageResource(R.drawable.ic_add_black_24dp);
                vh.btnAdd.setTag("Add");
            }
        }
        else if(ingredients.size()==1)
        {
            vh.btnAdd.setTag("Add");
        }
        return vh;
    }


    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        holder.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.findViewById(R.id.btnAdd).getTag().equals("Close")) {
                    ingredients.remove(holder.getPosition());
                    notifyItemRemoved(holder.getPosition());

                } else if(v.findViewById(R.id.btnAdd).getTag().equals("Add") || v.findViewById(R.id.btnAdd).getTag() == null){
                    if (ingredients.size()==5){
                        Toast.makeText(cont, "You can't add more than 5 ingredients for searching.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    ingredients.add("");

                    notifyItemInserted(0);

                    Log.d("test", "inside onclick");
                }
            }
        });

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return ingredients.size();
    }



}