package com.example.hw04_grup19;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class RecipesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    ArrayList<RecipeResult> arrcp = new ArrayList<>();

    public RecipesAdapter(ArrayList<RecipeResult> arrcp) {
        this.arrcp = arrcp;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.ingredients, null, false);


        ViewHolder vh = new ViewHolder(view);

        vh.tv1.setText((CharSequence) arrcp.get(i).title);
        vh.tv2.setText((CharSequence) arrcp.get(i).ing);
        vh.tv3.setText((CharSequence) arrcp.get(i).url);
        //Picasso.get().load(arrcp.get(i).image).into(vh.iv);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {


    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv1, tv2, tv3;
        ImageView iv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv = itemView.findViewById(R.id.imageView);
            tv1 = itemView.findViewById(R.id.titleresult);
            tv2 = itemView.findViewById(R.id.ingresults);
            tv3 = itemView.findViewById(R.id.urlresult);

        }
    }

    @Override
    public int getItemCount() {
        return arrcp.size();
    }
}
