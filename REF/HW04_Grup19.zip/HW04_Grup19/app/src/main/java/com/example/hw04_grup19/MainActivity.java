package com.example.hw04_grup19;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements firstFragment.DisplayNextFragment{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Recipe Puppy");

        getSupportFragmentManager().beginTransaction()
                .add(R.id.Container, new firstFragment(),"first")
                .commit();

    }

    @Override
    public void displaySecondFragment(String url) {
        getSupportFragmentManager().beginTransaction()
                .add(R.id.Container, new secondFragment(),"second")
                .commit();
    }
}
