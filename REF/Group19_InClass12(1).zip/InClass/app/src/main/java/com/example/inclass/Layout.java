package com.example.inclass;

import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;


public class Layout extends ArrayAdapter<ChoosePlaces> {


    static ArrayList<ChoosePlaces> arrayList = new ArrayList<>();

    public Layout(Context context, int resource, List<ChoosePlaces> objects) {
        super(context, resource, objects);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final ChoosePlaces choosePlaces = (ChoosePlaces) getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.listview_layout, parent, false);
        }

        TextView tv1;
        tv1 = convertView.findViewById(R.id.textView3);
        tv1.setText(choosePlaces.placename);

        final CheckBox cb = convertView.findViewById(R.id.checkBox);
        cb.setChecked(false);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {  Log.d("layout","ahfjkahf");
                if (isChecked) {
                    cb.setChecked(true);
                    Toast.makeText(getContext(), "Place Checked", Toast.LENGTH_SHORT).show();
                    if(arrayList.size()<16)
                    {

                        arrayList.add(choosePlaces);
                    }
                    else
                    {
                        Toast.makeText(getContext(), "You can add Maximum 15 places", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Log.d("demo", choosePlaces.toString());
                   // cb.setChecked(false);
                    arrayList.remove(choosePlaces);

                }
            }
        });





        return convertView;

    }

}
