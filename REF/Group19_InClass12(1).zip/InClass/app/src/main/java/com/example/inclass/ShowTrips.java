package com.example.inclass;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;



public class ShowTrips extends ArrayAdapter <FinalData>{


    public ShowTrips(Context context, int resource,List objects) {
        super(context, resource, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final FinalData finalData = (FinalData) getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.showtrip, parent, false);
        }

        TextView tv1;
        tv1 = convertView.findViewById(R.id.tripname);
        tv1.setText(finalData.tripname);
        TextView tv2;
        tv2=convertView.findViewById(R.id.tripdate);
        tv2.setText(finalData.date);

        return convertView;

    }


}
