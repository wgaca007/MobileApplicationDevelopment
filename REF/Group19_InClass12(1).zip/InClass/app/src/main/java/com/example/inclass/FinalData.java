package com.example.inclass;

import java.util.ArrayList;

public class FinalData {

    public ArrayList<ChoosePlaces> placelist;
    public String tripname,date;

    public FinalData(ArrayList<ChoosePlaces> placelist, String tripname, String date) {
        this.placelist = placelist;
        this.tripname = tripname;
        this.date = date;
    }

    public FinalData(){
    }

    public ArrayList<ChoosePlaces> getPlacelist() {
        return placelist;
    }

    public void setPlacelist(ArrayList<ChoosePlaces> placelist) {
        this.placelist = placelist;
    }

    public String getTripname() {
        return tripname;
    }

    public void setTripname(String tripname) {
        this.tripname = tripname;
    }
}
