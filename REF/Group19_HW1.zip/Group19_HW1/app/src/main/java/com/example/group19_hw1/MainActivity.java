package com.example.group19_hw1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.KeyListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.util.Log;
import android.widget.CompoundButton;
import android.view.Gravity;
import android.widget.Toast;

import java.util.ArrayList;
import java.text.DecimalFormat;

import static android.widget.SeekBar.*;

public class MainActivity extends AppCompatActivity {

    int progressValue = 5;
    String value;
    EditText weight;
    String g = "F";
    Double cost = 0.55;
    String input_weight;
    int wt_in;
    int d_value;
    Double bac_value_sum = 0.0;
    int flag;
    int wzerochk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("BAC Calculator");
        final Switch gender;
        final Button save = findViewById(R.id.button_save);
        gender = (Switch) findViewById(R.id.switch_gender);
        Switch sw = (Switch) findViewById(R.id.switch_gender);
        final EditText wip = (EditText) findViewById(R.id.Weight_Input);
        final RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        final SeekBar sb = (SeekBar) findViewById(R.id.seekBar);
        final Button addDrinks = (Button) findViewById(R.id.AddDrink);


        save.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {



                flag=1;

                if(wip.getText().toString().isEmpty())
                {
                    wip.setError("Please input weight in pounds.");
                    return;
                }

                TextView zerochk= (TextView) findViewById(R.id.Weight_Input);
                String zerochks= zerochk.getText().toString();
                wzerochk= Integer.parseInt(zerochks);
                if(wzerochk ==0 )
                {
                    wip.setError("Weight should be a non negative integer");
                    return;
                }

                TextView wt = findViewById(R.id.Weight_Input);
                input_weight = wt.getText().toString();
                wt_in = Integer.parseInt(input_weight);
            }
        });

        gender.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    g = "M";
                    cost = 0.55;
                } else {
                    g = "F";
                    cost = 0.68;
                }
            }
        });

        final SeekBar alcohol_seekbar = (SeekBar) findViewById(R.id.seekBar);
        alcohol_seekbar.setMax(25);
        final TextView slider = findViewById(R.id.Slider);

        alcohol_seekbar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < 5) {
                    alcohol_seekbar.setProgress(0);
                    slider.setText("0%");
                } else {
                    int interval = 5;
                    progress = (progress / interval) * interval;
                    alcohol_seekbar.setProgress(progress);
                    progressValue = progress;
                    slider.setText(progress + "%");
                }
            }


            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        Button ad = findViewById(R.id.AddDrink);

        ad.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {


                if (flag != 1)
                {
                    Toast toast = Toast.makeText(getApplicationContext(), "Please click the save button", Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }
                RadioGroup rg = findViewById(R.id.radioGroup);
                RadioButton rb = findViewById(rg.getCheckedRadioButtonId());
                String drink_value = rb.getText().toString();
                if (drink_value.equals("1 oz")) {
                    d_value = 1;
                    Log.d("demo", "1rb selected");
                } else if (drink_value.equals("5 oz")) {
                    d_value = 5;
                } else {
                    d_value = 12;
                }


                Double BACValue = (d_value * progressValue * 0.64) / (wt_in * cost);
                bac_value_sum = bac_value_sum + BACValue;


                double roundOff = Math.floor(bac_value_sum * 1e2) / 1e2;

                System.out.println();
                TextView tv_bac = (TextView) findViewById(R.id.textView_bac);

                tv_bac.setText(String.valueOf(roundOff));
                TextView msg = findViewById(R.id.status);
                if (roundOff > 0.08 && roundOff < 0.20) {
                    msg.setText("Be careful...");
                    msg.setBackgroundColor(Color.rgb(255, 165, 0));
                    msg.setTextColor(Color.WHITE);
                }
                else if (roundOff >= 0.20) {
                    wip.setEnabled(false);
                    save.setEnabled(false);
                    gender.setEnabled(false);

                    for(int i = 0; i < radioGroup.getChildCount(); i++){
                        ((RadioButton)radioGroup.getChildAt(i)).setEnabled(false);
                    }

                    sb.setEnabled(false);
                    addDrinks.setEnabled(false);
                    msg.setText("Over the limit!");
                    Toast toast = Toast.makeText(getApplicationContext(), "No more drinks for you!", Toast.LENGTH_SHORT);
                    toast.show();
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    msg.setBackgroundColor(Color.RED);
                    msg.setTextColor(Color.WHITE);


                }
                else
                {
                    msg.setText("You're safe!");
                    msg.setBackgroundColor(Color.GREEN);
                    msg.setTextColor(Color.WHITE);
                }

            }
        });

        findViewById(R.id.Reset).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                wip.setText("");
                wip.setEnabled(true);
                save.setEnabled(true);
                gender.setEnabled(true);

                for(int i = 0; i < radioGroup.getChildCount(); i++){
                    ((RadioButton)radioGroup.getChildAt(i)).setEnabled(true);
                }

                ((RadioButton)radioGroup.getChildAt(0)).setChecked(true);
                sb.setEnabled(true);
                sb.setProgress(0);
                TextView bacLevel = (TextView) findViewById(R.id.textView_bac);
                TextView status = (TextView) findViewById(R.id.status);
                bacLevel.setText("");
                status.setText("");
                addDrinks.setEnabled(true);
                gender.setTextOff("F");
                bac_value_sum = 0.0;
                g = "F";
                cost = 0.55;
                progressValue = 5;
                flag=0;

            }
        });


    }

}


