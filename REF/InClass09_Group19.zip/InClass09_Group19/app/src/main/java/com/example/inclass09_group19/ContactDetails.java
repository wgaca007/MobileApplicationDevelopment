package com.example.inclass09_group19;

public class ContactDetails {
    public String Name, EmailID, imgURL, ContactNo;


}
