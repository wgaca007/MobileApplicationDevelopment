package com.example.inclass09_group19;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;

import static android.app.Activity.RESULT_OK;

public class FifthFragment extends Fragment {
    private OnFragmentInteractionListener mlistener;

    static final int REQUEST_IMAGE_CAPTURE = 1;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            mlistener.sendbitmap(imageBitmap);
        }
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
       void sendbitmap(Bitmap imageBitmap);
    }
}