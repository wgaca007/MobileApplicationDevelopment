package com.example.group19_hw02_;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class generatePwd extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.generated_pwd);
        setTitle("Generated Passwords");


        String[] async = MainActivity.async;
        String[] thread = MainActivity.thread;


        LinearLayout mainlayout = (LinearLayout)findViewById(R.id.svThreadLinear);

        LayoutInflater layoutInflater = (LayoutInflater) getLayoutInflater();
        View view;
        for (int i = 0; i < thread.length; i++){

            view = layoutInflater.inflate(R.layout.textview,mainlayout,false);

            TextView textView = (TextView)view.findViewById(R.id.mytext);
            textView.setText(thread[i]);
            textView.setMovementMethod(new ScrollingMovementMethod());
            mainlayout.addView(view);
        }



        LinearLayout mainlayout1 = (LinearLayout)findViewById(R.id.svTAsyncLinear);

        LayoutInflater layoutInflater1 = (LayoutInflater) getLayoutInflater();

        for (int i = 0; i < async.length; i++){

            view = layoutInflater1.inflate(R.layout.textview,mainlayout,false);

            TextView textView = (TextView)view.findViewById(R.id.mytext);
            textView.setText(async[i]);
            textView.setMovementMethod(new ScrollingMovementMethod());
            mainlayout1.addView(view);
        }


    }
}
