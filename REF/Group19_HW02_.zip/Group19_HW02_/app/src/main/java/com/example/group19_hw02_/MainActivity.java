package com.example.group19_hw02_;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Scroller;
import android.widget.SeekBar;
import android.widget.TextView;


import org.w3c.dom.Text;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {
    Handler handler;
    int txtTHPwdCnt =1, txtTHPwdLen=7, txtAsyncPwdCnt=1, txtAsyncPwdLen=7;
    ProgressDialog pb;
    TextView txtGenCnt, txtPerc;
    static String[] async;
    static String[] thread;
    static AtomicInteger count = new AtomicInteger(0);

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Password Generator");

        final SeekBar sbTh1 = (SeekBar) findViewById(R.id.sbPwdCnt);
        final SeekBar sbTh2 = (SeekBar) findViewById(R.id.sbPwdLength);
        final SeekBar sbAT1 = (SeekBar) findViewById(R.id.sbAsyncPwdCnt);
        final SeekBar sbAT2 = (SeekBar) findViewById(R.id.sbAsyncPwdLength);

//        sbTh1.setMin(1);
//        sbTh2.setMin(7);
//        sbAT1.setMin(1);
//        sbAT2.setMin(7);

        sbTh1.setMax(10);
        sbTh2.setMax(23);
        sbAT1.setMax(10);
        sbAT2.setMax(23);


        final TextView txtPwdCnt = (TextView) findViewById(R.id.txtvwPwdCnt);
        final TextView txtPwdLength = (TextView) findViewById(R.id.txtvwPwdLength);
        final TextView txtATPwdCnt = (TextView) findViewById(R.id.txtvwAsyncPwdCnt);
        final TextView txtATPwdLength = (TextView) findViewById(R.id.txtvwAsyncPwdLength);

        final TextView txtThread = (TextView) findViewById(R.id.tvThread);
        final TextView txtTHSelectPwdCnt = (TextView) findViewById(R.id.tvTHSelPwdCnt);
        final TextView txtTHSelectPwdLen = (TextView) findViewById(R.id.tvTHSelPwdLen);
        final TextView txtAsync = (TextView) findViewById(R.id.tvAsync);
        final TextView txtATSelectPwdCnt = (TextView) findViewById(R.id.tvATSelPwdCnt);
        final TextView txtATSelectPwdLen = (TextView) findViewById(R.id.tvATSelPwdLen);

        sbTh1.setProgress(1);
        sbTh2.setProgress(7);
        sbAT1.setProgress(1);
        sbAT2.setProgress(7);
        txtPwdCnt.setText("1");
        txtPwdLength.setText("7");
        txtATPwdCnt.setText("1");
        txtATPwdLength.setText("7");

        final Button btnGenerate = (Button) findViewById(R.id.btnGenerate);


        pb = new ProgressDialog(this);
        pb.setProgress(0);
        pb.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pb.setCancelable(false);


        sbTh1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < 1) {
                    sbTh1.setProgress(0);
                    txtPwdCnt.setText("0");
                    txtTHPwdCnt = 0;
                } else {
                    int interval = 1;
                    progress = (progress / interval) * interval;
                    sbTh1.setProgress(progress);
                    txtPwdCnt.setText(progress + "");
                    txtTHPwdCnt = Integer.parseInt(String.valueOf(progress));
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        sbAT1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < 1) {
                    sbAT1.setProgress(0);
                    txtATPwdCnt.setText("0");
                    txtAsyncPwdCnt = 0;
                } else {
                    int interval = 1;
                    progress = (progress / interval) * interval;
                    sbAT1.setProgress(progress);
                    txtATPwdCnt.setText(progress + "");
                    txtAsyncPwdCnt = Integer.parseInt(String.valueOf(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        sbTh2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < 7) {
                    sbTh2.setProgress(0);
                    txtPwdLength.setText("0");
                    txtTHPwdLen = 0;
                } else {
                    int interval = 1;
                    progress = (progress / interval) * interval;
                    sbTh2.setProgress(progress);
                    txtPwdLength.setText(progress + "");
                    txtTHPwdLen = Integer.parseInt(String.valueOf(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        sbAT2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress < 7) {
                    sbAT2.setProgress(0);
                    txtATPwdLength.setText("0");
                    txtAsyncPwdLen = 0;
                } else {
                    int interval = 1;
                    progress = (progress / interval) * interval;
                    sbAT2.setProgress(progress);
                    txtATPwdLength.setText(progress + "");
                    txtAsyncPwdLen = Integer.parseInt(String.valueOf(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btnGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                pb.setVisibility(View.VISIBLE);

                txtThread.setVisibility(View.INVISIBLE);
                txtTHSelectPwdCnt.setVisibility(View.INVISIBLE);
                txtTHSelectPwdLen.setVisibility(View.INVISIBLE);
                txtPwdCnt.setVisibility(View.INVISIBLE);
                sbTh1.setVisibility(View.INVISIBLE);
                txtPwdLength.setVisibility(View.INVISIBLE);
                sbTh2.setVisibility(View.INVISIBLE);
                thread = new String[txtTHPwdCnt];
                async = new String[txtAsyncPwdCnt];

                txtAsync.setVisibility(View.INVISIBLE);
                txtATSelectPwdCnt.setVisibility(View.INVISIBLE);
                txtATSelectPwdLen.setVisibility(View.INVISIBLE);
                txtATPwdCnt.setVisibility(View.INVISIBLE);
                sbAT1.setVisibility(View.INVISIBLE);
                txtATPwdLength.setVisibility(View.INVISIBLE);
                sbAT2.setVisibility(View.INVISIBLE);

                btnGenerate.setVisibility(View.INVISIBLE);

                pb.setMax(txtTHPwdCnt + txtAsyncPwdCnt);
                pb.show();

                handler = new Handler(new Handler.Callback() {


                    @Override
                    public boolean handleMessage(Message msg) {


                        //  getArgument.getByteArrayExtra("image");
                        if (msg.getData().containsKey("progressCnt")) {

                            int currProgress = pb.getProgress();

                            pb.setProgress(count.get());
//                            int getCurrMax = pb.getMax();

//                            txtPerc.setText((((currProgress+msg.getData().getInt("progressCnt"))/getCurrMax)*100) + "%");
//                            txtGenCnt.setText((currProgress+msg.getData().getInt("progressCnt")) + "/" + getCurrMax);

                        } else if (msg.getData().containsKey("TH_PWD")) {

                            pb.setProgress(count.get());

                            if (msg.getData().containsKey("async")) {
                                async = msg.getData().getStringArray("TH_PWD");
                            } else {
                                thread = msg.getData().getStringArray("TH_PWD");
                            }

                            Log.d("count", "" + count.get());
                            if (count.get() == (txtAsyncPwdCnt + txtTHPwdCnt)) {
                                Intent i = new Intent(MainActivity.this, generatePwd.class);
                                startActivity(i);
                            }

                        }
                        return false;
                    }
                });

                ExecutorService thPool = Executors.newFixedThreadPool(2);
                thPool.execute(new GetGeneratedPasswords(txtTHPwdCnt, txtTHPwdLen));


                new GeneratePwdAsync().execute(txtAsyncPwdCnt, txtAsyncPwdLen);

            }
        });


    }


    class GetGeneratedPasswords implements Runnable {
        int thPwdCnt;
        int thPwdLength;

        public GetGeneratedPasswords(int thPwdCnt, int thPwdLength) {
            this.thPwdCnt = thPwdCnt;
            this.thPwdLength = thPwdLength;
        }

        @Override
        public void run() {
            Bundle bd;
            Message msg;
            try {

                Log.d("d", "inside thread");
                String[] generatedPwd = new String[thPwdCnt];

                for (int i = 0; i < thPwdCnt; i++) {
                    Log.d("d", "inside for" + thPwdLength);
                    generatedPwd[i] = Util.getPassword(thPwdLength);
                    Log.d("generated",generatedPwd[i]);
                    count.getAndIncrement();
                    Log.d("d", generatedPwd[i]);
                    bd = new Bundle();
                    msg = new Message();
                    bd.putInt("progressCnt", 1);
                    msg.setData(bd);
                    Log.d("d", "Thread");
                    handler.sendMessage(msg);

                }

                bd = new Bundle();
                msg = new Message();
                bd.putStringArray("TH_PWD", generatedPwd);
                msg.setData(bd);
                handler.sendMessage(msg);
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }

        }
    }


    class GeneratePwdAsync extends AsyncTask<Integer, Integer, String[]> {

        Bundle bd;
        Message msg;
        String[] generatedPwd;


        @Override
        protected String[] doInBackground(Integer... integers) {

            generatedPwd = new String[integers[0]];
            Log.d("Integers[0]", integers[0] + "");
            for (int i = 0; i < integers[0]; i++) {
                generatedPwd[i] = Util.getPassword(integers[1]);
                count.getAndIncrement();
                bd = new Bundle();
                msg = new Message();
                bd.putInt("progressCnt", 1);
                msg.setData(bd);
                Log.d("d", "Async");
                handler.sendMessage(msg);
            }
            return generatedPwd;
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onPostExecute(String[] genPwd) {
            bd = new Bundle();
            msg = new Message();
            bd.putStringArray("TH_PWD", generatedPwd);
            bd.putBoolean("async", true);
            msg.setData(bd);
            handler.sendMessage(msg);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {

//           Activity alert = (Activity) getResources().getLayout(R.layout.alert);
//           pb = (ProgressBar) alert.findViewById(R.id.progressBar);
//           txtPerc = (TextView) alert.findViewById(R.id.txtPerc);
//           txtGenCnt = (TextView) alert.findViewById(R.id.txtGenCnt);
//
//           int currProgress = pb.getProgress();
//           pb.setProgress(currProgress+values[0]);
//           int getCurrMax = pb.getMax();
//
//           txtPerc.setText((((currProgress+values[0])/getCurrMax)*100) + "%");
//           txtGenCnt.setText((currProgress+values[0]) + "/" + getCurrMax);


        }

    }
}
