package com.example.group19_inclass07;

import java.util.Date;

public class ExpenseDetails {

    String ename,category;
    double amount;
    Date dt;
}
