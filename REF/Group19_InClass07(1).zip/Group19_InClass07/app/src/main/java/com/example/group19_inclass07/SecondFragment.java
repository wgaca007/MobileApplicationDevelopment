package com.example.group19_inclass07;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Calendar;


public class SecondFragment extends Fragment {
    Context cont;
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final Spinner spinner = (Spinner) getActivity().findViewById(R.id.spinnerCategory);
        //String spinner_selected=spinner.getSelectedItem().toString();
        final EditText txtName = (EditText) getActivity().findViewById(R.id.txtExpenseName);
        final EditText txtAmount = (EditText) getActivity().findViewById(R.id.txtAmount);


        getActivity().findViewById(R.id.btnAddExpense).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    if(txtName.getText().toString().isEmpty()){
                        Toast.makeText(cont, "Please enter expense name.", Toast.LENGTH_SHORT).show();
                        //txtName.setError("Please enter expense name.");
                        return;
                    }

                    if(txtAmount.getText().toString().isEmpty()){
                        Toast.makeText(cont, "Please enter expense amount.", Toast.LENGTH_SHORT).show();
                        //txtAmount.setError("Please enter expense amount.");
                        return;
                    }


                    ExpenseDetails expenseDetails = new ExpenseDetails();
                    expenseDetails.ename = txtName.getText().toString();
                    expenseDetails.amount = Double.parseDouble(txtAmount.getText().toString());
                    expenseDetails.category = spinner.getSelectedItem().toString();
                    expenseDetails.dt =  Calendar.getInstance().getTime();
                    mListener.AddExpense(expenseDetails);
                }
            }
        });

        getActivity().findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) {
                    mListener.CancelExpense();
                }
            }
        });

    }
 private OnFragmentInteractionListener mListener;

    public SecondFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        cont = context;
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void AddExpense(ExpenseDetails expenseDetails);
        void CancelExpense();
    }
}
