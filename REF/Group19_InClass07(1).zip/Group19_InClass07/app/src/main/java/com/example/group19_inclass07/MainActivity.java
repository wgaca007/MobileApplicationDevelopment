package com.example.group19_inclass07;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.ActionMode;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements FirstFragment.IgetMainactivity
        , SecondFragment.OnFragmentInteractionListener, thirdFragment.OnFragmentInteractionListener{
ArrayList<ExpenseDetails> arrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Expense App");

        getSupportFragmentManager().beginTransaction()
                .add(R.id.Container,new FirstFragment(new ArrayList<ExpenseDetails>()), "first")
                .addToBackStack("first")
                .commit();

    }

    @Override
    public void callSecondFragment() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Container,new SecondFragment(), "second")
                .addToBackStack("second")
                .commit();
        setTitle("Add Expense");
    }

    @Override
    public void expenseClicked(ExpenseDetails expenseDetails) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Container,new thirdFragment(expenseDetails), "third")
                .addToBackStack("third")
                .commit();
        setTitle("Show Expense");
    }

    @Override
    public void updateArrayList(ArrayList<ExpenseDetails> expenseDetails) {
        arrayList = expenseDetails;

    }

    @Override
    public void AddExpense(ExpenseDetails expenseDetails) {
        arrayList.add(expenseDetails);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Container,new FirstFragment(arrayList), "first")
                .addToBackStack("first")
                .commit();

        setTitle("Expense App");
    }

    @Override
    public void CancelExpense() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Container,new FirstFragment(arrayList), "first")
                .addToBackStack("first")
                .commit();
        setTitle("Expense App");
    }

    @Override
    public void clickClose() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Container,new FirstFragment(arrayList), "first")
                .addToBackStack("first")
                .commit();
        setTitle("Expense App");
    }

    @Override
    public void onBackPressed() {
       if(getSupportFragmentManager().getBackStackEntryCount()>0)
       {
           getSupportFragmentManager().popBackStack();
       }
       else
       {
           super.onBackPressed();
       }


    }
}
