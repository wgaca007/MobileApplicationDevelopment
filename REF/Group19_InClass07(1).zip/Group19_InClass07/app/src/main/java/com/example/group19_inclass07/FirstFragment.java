package com.example.group19_inclass07;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class FirstFragment extends Fragment {
    ArrayList<ExpenseDetails> arrExpenseDetails = new ArrayList<>();
    IgetMainactivity mListener;
    Context cont;
    Lvadapter lvadapter;

    @SuppressLint("ValidFragment")
    public FirstFragment(ArrayList<ExpenseDetails> arrExpenseDetails) {
        this.arrExpenseDetails = arrExpenseDetails;
    }

    @Override
    public void onAttach(Context context) {

        super.onAttach(context);
        mListener = (IgetMainactivity) context;
        cont = context;

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (mListener != null) {


            if (this.arrExpenseDetails.size() > 0) {
                getActivity().findViewById(R.id.txtVwMsg).setVisibility(View.INVISIBLE);

                final ListView listView = (ListView) getActivity().findViewById(R.id.listVwExpenses);
                listView.setVisibility(View.VISIBLE);

                lvadapter = new Lvadapter(cont, R.layout.expense_list, arrExpenseDetails);

                listView.setAdapter(lvadapter);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        mListener.expenseClicked(arrExpenseDetails.get(position));
                    }
                });

                listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                        arrExpenseDetails.remove(position);
                        Toast.makeText(cont, "Expense Deleted.", Toast.LENGTH_SHORT).show();
                        listView.setAdapter(lvadapter);

                        if(arrExpenseDetails.size() == 0)
                        {
                            getActivity().findViewById(R.id.txtVwMsg).setVisibility(View.VISIBLE);

                            ListView listView = (ListView) getActivity().findViewById(R.id.listVwExpenses);
                            listView.setVisibility(View.INVISIBLE);
                        }

                        mListener.updateArrayList(arrExpenseDetails);

                        return true;
                    }
                });
            } else {
                getActivity().findViewById(R.id.txtVwMsg).setVisibility(View.VISIBLE);
                ListView listView = (ListView) getActivity().findViewById(R.id.listVwExpenses);
                listView.setVisibility(View.INVISIBLE);
            }

            getActivity().findViewById(R.id.buttonadd).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.callSecondFragment();
                }
            });
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    public interface IgetMainactivity {
        void callSecondFragment();
        void expenseClicked(ExpenseDetails expenseDetails);
        void updateArrayList(ArrayList<ExpenseDetails> expenseDetails);
    }


}
