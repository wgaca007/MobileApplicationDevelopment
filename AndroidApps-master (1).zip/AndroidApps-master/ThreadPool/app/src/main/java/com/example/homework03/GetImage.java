package com.example.homework03;

public class GetImage {

}
