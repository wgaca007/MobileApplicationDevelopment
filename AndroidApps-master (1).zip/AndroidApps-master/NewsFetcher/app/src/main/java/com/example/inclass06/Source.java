package com.example.inclass06;

public class Source {
    String title, publishedat, imageurl, description;

}
