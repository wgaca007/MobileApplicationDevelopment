package com.example.homework05;

public class News {
    String author,title,url,urlToImage,publishedat;

    public News(String author, String title, String url, String urlToImage, String publishedat) {
        this.author = author;
        this.title = title;
        this.url = url;
        this.urlToImage = urlToImage;
        this.publishedat = publishedat;
    }
}
