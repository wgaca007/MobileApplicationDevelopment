package com.example.inclass07;


public class Song {

    public String title, artistname, albumname, date, trackshareurl;

    public Song(String title, String artistname, String albumname, String date, String trackshareurl) {
        this.title = title;
        this.artistname = artistname;
        this.albumname = albumname;
        this.date = date;
        this.trackshareurl = trackshareurl;
    }
}
