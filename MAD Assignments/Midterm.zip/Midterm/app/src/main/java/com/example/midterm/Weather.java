package com.example.midterm;

public class Weather {
    String temp,tempmax,tempmin,desc,humidity,speed;

    public Weather(String temp, String tempmax, String tempmin, String desc, String humidity, String speed) {
        this.temp = temp;
        this.tempmax = tempmax;
        this.tempmin = tempmin;
        this.desc = desc;
        this.humidity = humidity;
        this.speed = speed;
    }
}
